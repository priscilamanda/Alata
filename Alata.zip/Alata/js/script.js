function validasi() {
    var laporan = document.getElementById("laporan").value;
    var foto = document.getElementById("foto").value;
    if (laporan != "" && foto!="") {
        alert('Thank you for reporting the environmental violation. Your report has been successfully submitted. Our team will carefully review your report and initiate the necessary processes to address the violation.');
    }else{
        alert('Incomplete data !');
    }
}

function tambah() {
    var nama_laut = document.getElementById("nama_laut").value;
    var lokasi = document.getElementById("lokasi").value;
    if (nama_laut != "" && lokasi !="") {
        alert('New location has been successfully added.');
    }else{
        alert('Incomplete data !');
    }
}

